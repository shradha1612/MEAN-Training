// import { Component, Input } from '@angular/core';
// import { Cart } from '../model/Cart';
// import { Router } from '@angular/router';
// import { CartManagementService } from '../cart-management.service';

// @Component({
//   selector: 'app-cart',
//   standalone: false,
//   templateUrl: './cart.component.html',
//   styleUrls: ['./cart.component.css']
// })
// export class CartComponent {
//   cartArr: Cart[];
//   constructor(private router: Router, cms:CartManagementService) {
//     this.cartArr = cms.getAllCartItems();
//   }
//   proceedToPaymentEventHandler() {
//     //navigate to /payments
//     this.router.navigate(['/payments']);
//   }
// }




import { Component, Input } from '@angular/core';
import { Cart } from '../model/Cart';
import { Router } from '@angular/router';
import { CartManagementService} from '../cart-management.service';

@Component({
  selector: 'app-cart',
  standalone: false,
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent {
  cartArr: Cart[];
  constructor(private router: Router, cms:CartManagementService) {
    this.cartArr = cms.getAllCartItems();
  }

  calculateSubtotal(): number {
    return this.cartArr.reduce((total, product) => {
        return total + (product.premium * product.quantitySelected);
    }, 0);
}
  proceedToPaymentEventHandler() {
    //navigate to /payments
    this.router.navigate(['/payments']);
  }
}
