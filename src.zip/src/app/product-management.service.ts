import { Injectable } from '@angular/core';
import { Products } from './model/Products';

@Injectable()
export class ProductManagementService {
  productsArr: Products[];
  constructor() {
    this.productsArr = [
      new Products(101, "Cappucino", "cappu.jpg", "Cappucino", 200, 4, "200"),
      new Products(102, "Cafe latte", "latte.jpg", "Cafe latte", 300, 5, "7 Lakhs"),
      new Products(103, "Mocha", "mocha1.jpg", "Mocha", 300, 3, "5 Lakhs"),
      new Products(104, "Espresso", "expresso.jpg", "Americano", 299, 6, "3 Lakhs"),
      new Products(105, "Macchiato", "OIP.jpg", "Macchiato", 399, 7, "4 Lakhs"),
      new Products(106, "Cortado", "cortado.jpg", "Cortado", 499, 7, "1 Lakh"),
      new Products(106, "Americano", "mocha.jpg", "Cortado", 499, 7, "1 Lakh")
    ];
  }
  addProductsItem(ProductsObj: Products) {
    this.productsArr.push(ProductsObj);
    console.log(this.productsArr)
  }
  getAllProductsItems() {
    return this.productsArr;
  }
  deleteProductsItem(productId: number) {
    var pos = this.productsArr.findIndex(item => item.productId == productId);
    if (pos >= 0) {
      this.productsArr.splice(pos, 1);
      return true;
    }
    else {
      return false;
    }
  }
}
