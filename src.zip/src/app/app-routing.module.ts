import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { RegisterTemplateComponent } from './register-template/register-template.component';
import { RegisterModelComponent } from './register-model/register-model.component';
import { TwoWayDataBindingExampleComponent } from './two-way-data-binding-example/two-way-data-binding-example.component';
import { SearchProductsComponent } from './search-products/search-products.component';
import { DirectiveExamplesComponent } from './directive-examples/directive-examples.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { PaymentsComponent } from './payments/payments.component';
import { PaymentByCardComponent } from './payment-by-card/payment-by-card.component';
import { PaymentByWalletComponent } from './payment-by-wallet/payment-by-wallet.component';
import { PaymentByUPIComponent } from './payment-by-upi/payment-by-upi.component';
import { PaymentByNetBankingComponent } from './payment-by-net-banking/payment-by-net-banking.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { CartComponent } from './cart/cart.component';

const routes: Routes = [
  { path: "products", component: HomeComponent },
  { path: "productDetails/:productId", component: ProductDetailsComponent },
  { path: "registerTemplate", component: RegisterTemplateComponent },
  { path: "registerReactive", component: RegisterModelComponent },
  { path: "twowayBinding", component: TwoWayDataBindingExampleComponent },
  { path: "searchProducts", component: SearchProductsComponent },
  { path: "directiveExamples", component: DirectiveExamplesComponent },
    { path: "cart", component: CartComponent},
  
  {
    path: "payments", component: PaymentsComponent,
    children: [
      { path: "card", component: PaymentByCardComponent },
      { path: "wallet", component: PaymentByWalletComponent },
      { path: "upi", component: PaymentByUPIComponent },
      { path: "netbanking", component: PaymentByNetBankingComponent },
      { path: "", redirectTo: "card", pathMatch: "full" },

    ]
  },
  { path: "", redirectTo: "products", pathMatch: "full" }, // "http://localhost:4200"
  // { path: "**", redirectTo: "products", pathMatch: "full" },
  { path: "**", component: PageNotFoundComponent}// "http://localhost:4200/anyrandompath"

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
