import { Component } from '@angular/core';

@Component({
  selector: 'app-header',
  standalone: false,
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {
  userId: string = 'User123'; // Replace this with the actual user ID logic

  constructor() {
    // Logic to fetch or set the userId can go here
  }
}
