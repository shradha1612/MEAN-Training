import { Component } from '@angular/core';

@Component({
  selector: 'app-register-template',
  standalone: false,
  templateUrl: './register-template.component.html',
  styleUrls: ['./register-template.component.css']
})
export class RegisterTemplateComponent {
 router: any;
 submitEventHandler(registerFormValue: any){
  // Show success alert
  alert('Login successful! Welcome!');
  console.log(registerFormValue);
  // send this data to the server via POST request
 }

 RedirectEventHandlerSignUp() {
    //navigate to /payments
    this.router.navigate(['/payments']);
    console.log("form");
  }
}
