import { Component, EventEmitter, Input, Output, OnChanges, OnInit, SimpleChanges, OnDestroy } from '@angular/core';
import { Products } from '../model/Products';
import { Cart } from '../model/Cart';
import { CartManagementService } from '../cart-management.service';

@Component({
  selector: 'app-add-to-cart',
  standalone: false,
  templateUrl: './add-to-cart.component.html',
  styleUrls: ['./add-to-cart.component.css']
})
export class AddToCartComponent implements OnInit, OnChanges {
  cartObj: Cart | null;
  quantitySelected: number;

  @Input() companyName: string; 
  @Input("selProduct") product: Products | null;
  
  @Output() sendDataFromAddToCartToPD: EventEmitter<Cart | null>;
  @Output() sendCancelEventFromAddToCartToPD: EventEmitter<Cart | void>;
  

  constructor(private cartManagementService: CartManagementService) {
    console.log("Constructor of Add To cart called")
    this.companyName = "Marsh";
    this.product = null;
    this.quantitySelected = 1;
    this.sendDataFromAddToCartToPD = new EventEmitter<Cart | null>();
    this.sendCancelEventFromAddToCartToPD = new EventEmitter<Cart | void>();
    this.cartObj = null;
     
  }
  ngOnDestroy(): void {
    if (this.cartObj) {
      alert("Items added to the cart: " + this.product?.productId);
    }
    else {
      alert("Apologies, items cancelled: " +  this.product?.productId);
    }
  }
  ngOnChanges(changes: SimpleChanges): void {
    console.log("ngOnChange in Add to Cart called");
    console.log("Changes", changes);
    if(changes['product'] && changes['product'].previousValue && changes['product'].currentValue.productId !== changes['product'].previousValue.productId){
      this.quantitySelected = 1;
    }
    console.log("Selected Product", this.product) ; // mounting -- UD; product clicked
    // constructor -- product -- null;
    // ngOnInit -- product -- data from the parent
    // when is the data from the parent assigned to the input decorators -- after ngOnChnages; before
    // Answer:-- data assignment -- ngOnChnages
  }

  ngOnInit() {
    console.log("ngOnInit of Add To cart called");
    console.log("Selected Product", this.product);
  }

  modifyQuantity(op: string) {
    if (op == "dec") {
      if (this.quantitySelected > 1) {
        this.quantitySelected--;
      }
    } else {
      if (this.product && (this.quantitySelected < this.product.quantity)) {
        this.quantitySelected++;
        console.log("Selected Quantity: " + this.quantitySelected);
      }
    }
  }

  confirmEventHandler() {
    this.cartObj = this.product? new Cart(this.product.productId, this.product.productName, this.product.imageUrl, this.product.description,this.product.premium,this.product.quantity,this.quantitySelected, this.product.insurerCover):null;
    // trigger the event or emit the event

    if(this.cartObj){
      this.sendDataFromAddToCartToPD.emit(this.cartObj);
    this.cartManagementService.addCartItem(this.cartObj)
    }
    
  }

  cancelEventHandler(){
    // trigger an event
    this.sendCancelEventFromAddToCartToPD.emit()
  }
}
