import { Component } from '@angular/core';
import { Products } from '../model/Products';

@Component({
  selector: 'app-search-products',
  standalone: false,
  templateUrl: './search-products.component.html',
  styleUrls: ['./search-products.component.css']
})
export class SearchProductsComponent {
  productsArr: Products[];
  searchText: string;
  fieldName: string;
  fieldsNameArr: string[];
  selectedProduct: Products | null;
  constructor() {
    this.selectedProduct = null;
    this.productsArr = [
      new Products(101, "Cappucino", "cappu.jpg", "Cappucino", 200, 4, "200"),
      new Products(102, "Cafe latte", "latte.jpg", "Cafe latte", 300, 5, "7 Lakhs"),
      new Products(103, "Mocha", "mocha.jpg", "Mocha", 300, 3, "5 Lakhs"),
      new Products(104, "Americano", "TurkishCappu.jpg", "Americano", 299, 6, "3 Lakhs"),
      new Products(105, "Macchiato", "OIP.jpg", "Macchiato", 399, 7, "4 Lakhs"),
      new Products(106, "Cortado", "cappu.jpg", "Cortado", 499, 7, "1 Lakh")
    ];
    this.searchText = "";
    this.fieldName= "";
    this.fieldsNameArr = ["productId", "productName", "Price", "quantity"];
  }
  searchEventHandler(text: string, fieldName: string) {
    this.searchText = text;
    this.fieldName = fieldName;
  }
  editEventHandler(selectedProduct: Products) {
    console.log("Edit Event handler");
    this.selectedProduct = selectedProduct;
  }
}
