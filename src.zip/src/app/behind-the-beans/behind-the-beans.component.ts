import { Component } from '@angular/core';

@Component({
  selector: 'app-behind-the-beans',
  standalone: false,
  templateUrl: './behind-the-beans.component.html',
  styleUrl: './behind-the-beans.component.css'
})
export class BehindTheBeansComponent {

}
