import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BehindTheBeansComponent } from './behind-the-beans.component';

describe('BehindTheBeansComponent', () => {
  let component: BehindTheBeansComponent;
  let fixture: ComponentFixture<BehindTheBeansComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [BehindTheBeansComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BehindTheBeansComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
