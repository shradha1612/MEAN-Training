import { Component, inject } from '@angular/core';
import { Products } from '../model/Products';
import { Cart } from '../model/Cart';
import { Router } from '@angular/router';
import { ProductManagementService } from '../product-management.service';

@Component({
  selector: 'app-product-display',
  standalone: false,
  templateUrl: './product-display.component.html',
  styleUrls: ['./product-display.component.css']
})
export class ProductDisplayComponent {
  productsArr: Products[];
  companyName: string;
  showAddToCart: boolean;
  selectedProduct: Products | null;
  productManagementService: ProductManagementService

  constructor(private router: Router) {
    this.productManagementService = inject(ProductManagementService)
    this.companyName = "Marsh";
    this.showAddToCart = false;
    this.selectedProduct = null;
    this.productsArr = this.productManagementService.getAllProductsItems();
  }

  addToCart(selectedProduct: Products) {
    alert("Product Added to cart: " + selectedProduct.productName);
    this.showAddToCart = true;
    this.selectedProduct = selectedProduct;
  }

  sendDataFromAddTOCartToPD(cartObj: Cart | null){ 
    if (cartObj!=null) {
      // update the quantity in productsArr
      var pos = this.productsArr.findIndex(product => product.productId == cartObj.productId);
      console.log("Position:" + pos);
      if (pos>=0) {
        this.productsArr[pos].quantity = this.productsArr[pos].quantity - cartObj.quantitySelected;
        console.log("this.productsArr[pos].quantity: " + this.productsArr[pos].quantity);
      }

      // unmount the child component
      this.showAddToCart = false;
      // selectedProduct -- null
      this.selectedProduct = null;
      // this.sendDataFromPDToCart.emit(cartObj);
    }
  }
  sendCancelEventFromAddTOCartToPD() {
    this.showAddToCart = false;
    this.selectedProduct = null;
  }
  detailsEventHandler(selectedProduct: Products) {
    // navigate to productdetails component
    this.router.navigate(["productDetails", selectedProduct.productId]);

  }
}
